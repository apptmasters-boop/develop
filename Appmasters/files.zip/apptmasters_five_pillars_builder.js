const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  HeadingLevel, AlignmentType, BorderStyle, WidthType, ShadingType,
  LevelFormat, PageBreak, Header, Footer, TabStopType,
  TabStopPosition, ExternalHyperlink
} = require('docx');
const fs = require('fs');

const COLORS = {
  pillar1: '1B4F72', // Perception — deep blue
  pillar2: '1E8449', // Memory — deep green
  pillar3: '6C3483', // Action — deep purple
  pillar4: '784212', // Collaboration — deep brown/amber
  pillar5: '922B21', // Safety & Ethics — deep red
  heading_bg: '1A1A2E',
  light_gray: 'F4F6F7',
  mid_gray: 'D5D8DC',
  dark_text: '1A1A2E',
  white: 'FFFFFF',
  accent_light1: 'D6EAF8',
  accent_light2: 'D5F5E3',
  accent_light3: 'E8DAEF',
  accent_light4: 'FDEBD0',
  accent_light5: 'FADBD8',
};

const border = { style: BorderStyle.SINGLE, size: 1, color: 'CCCCCC' };
const borders = { top: border, bottom: border, left: border, right: border };
const noBorder = { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' };
const noBorders = { top: noBorder, bottom: noBorder, left: noBorder, right: noBorder };

function makeHeading1(text, color = COLORS.dark_text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 400, after: 200 },
    children: [new TextRun({ text, bold: true, size: 36, color, font: 'Arial' })]
  });
}

function makeHeading2(text, color = COLORS.dark_text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 300, after: 160 },
    children: [new TextRun({ text, bold: true, size: 28, color, font: 'Arial' })]
  });
}

function makeHeading3(text, color = COLORS.dark_text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_3,
    spacing: { before: 240, after: 120 },
    children: [new TextRun({ text, bold: true, size: 24, color, font: 'Arial' })]
  });
}

function makeBody(text, options = {}) {
  return new Paragraph({
    spacing: { before: 80, after: 100 },
    children: [new TextRun({ text, size: 22, font: 'Arial', color: COLORS.dark_text, ...options })]
  });
}

function makeBullet(text, level = 0) {
  return new Paragraph({
    numbering: { reference: 'bullets', level },
    spacing: { before: 60, after: 60 },
    children: [new TextRun({ text, size: 22, font: 'Arial', color: COLORS.dark_text })]
  });
}

function makeSubBullet(text) {
  return makeBullet(text, 1);
}

function spacer(size = 120) {
  return new Paragraph({ spacing: { before: size, after: 0 }, children: [new TextRun('')] });
}

function makePillarBanner(number, title, subtitle, color) {
  return new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [9360],
    rows: [
      new TableRow({
        children: [
          new TableCell({
            borders: noBorders,
            shading: { fill: color, type: ShadingType.CLEAR },
            margins: { top: 200, bottom: 200, left: 300, right: 300 },
            children: [
              new Paragraph({
                children: [
                  new TextRun({ text: `PILLAR ${number}  `, size: 20, font: 'Arial', color: 'FFFFFF', bold: true }),
                  new TextRun({ text: `  ${title}`, size: 36, font: 'Arial', color: 'FFFFFF', bold: true }),
                ]
              }),
              new Paragraph({
                spacing: { before: 80 },
                children: [new TextRun({ text: subtitle, size: 20, font: 'Arial', color: 'E0E0E0', italics: true })]
              })
            ]
          })
        ]
      })
    ]
  });
}

function makeSectionCard(title, content_rows, bgColor, titleColor) {
  const contentCells = content_rows.map(row =>
    new TableRow({
      children: [
        new TableCell({
          borders: noBorders,
          shading: { fill: bgColor, type: ShadingType.CLEAR },
          margins: { top: 60, bottom: 60, left: 300, right: 120 },
          children: [new Paragraph({ children: [new TextRun({ text: row, size: 20, font: 'Arial', color: COLORS.dark_text })] })]
        })
      ]
    })
  );

  return new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [9360],
    rows: [
      new TableRow({
        children: [
          new TableCell({
            borders: noBorders,
            shading: { fill: titleColor, type: ShadingType.CLEAR },
            margins: { top: 100, bottom: 100, left: 300, right: 300 },
            children: [new Paragraph({ children: [new TextRun({ text: title, size: 22, font: 'Arial', color: 'FFFFFF', bold: true })] })]
          })
        ]
      }),
      ...contentCells
    ]
  });
}

function makeThreeColTable(col1Title, col2Title, col3Title, rows, headerColor) {
  const colW = 3120;
  const headerRow = new TableRow({
    children: [col1Title, col2Title, col3Title].map(t =>
      new TableCell({
        borders,
        shading: { fill: headerColor, type: ShadingType.CLEAR },
        width: { size: colW, type: WidthType.DXA },
        margins: { top: 80, bottom: 80, left: 120, right: 120 },
        children: [new Paragraph({ children: [new TextRun({ text: t, size: 20, font: 'Arial', color: 'FFFFFF', bold: true })] })]
      })
    )
  });

  const dataRows = rows.map(([c1, c2, c3], i) =>
    new TableRow({
      children: [c1, c2, c3].map(text =>
        new TableCell({
          borders,
          shading: { fill: i % 2 === 0 ? COLORS.light_gray : COLORS.white, type: ShadingType.CLEAR },
          width: { size: colW, type: WidthType.DXA },
          margins: { top: 80, bottom: 80, left: 120, right: 120 },
          children: [new Paragraph({ children: [new TextRun({ text, size: 20, font: 'Arial', color: COLORS.dark_text })] })]
        })
      )
    })
  );

  return new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [colW, colW, colW],
    rows: [headerRow, ...dataRows]
  });
}

function makeTwoColFeatureTable(rows, headerColor, h1, h2) {
  const headerRow = new TableRow({
    children: [h1, h2].map((t, i) =>
      new TableCell({
        borders,
        shading: { fill: headerColor, type: ShadingType.CLEAR },
        width: { size: i === 0 ? 2800 : 6560, type: WidthType.DXA },
        margins: { top: 80, bottom: 80, left: 120, right: 120 },
        children: [new Paragraph({ children: [new TextRun({ text: t, size: 20, font: 'Arial', color: 'FFFFFF', bold: true })] })]
      })
    )
  });
  const dataRows = rows.map(([c1, c2], i) =>
    new TableRow({
      children: [[c1, 2800], [c2, 6560]].map(([text, w]) =>
        new TableCell({
          borders,
          shading: { fill: i % 2 === 0 ? COLORS.light_gray : COLORS.white, type: ShadingType.CLEAR },
          width: { size: w, type: WidthType.DXA },
          margins: { top: 80, bottom: 80, left: 120, right: 120 },
          children: [new Paragraph({ children: [new TextRun({ text, size: 20, font: 'Arial', color: COLORS.dark_text })] })]
        })
      )
    })
  );
  return new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [2800, 6560],
    rows: [headerRow, ...dataRows]
  });
}

// ─────────────────────────────────────────────
// COVER PAGE
// ─────────────────────────────────────────────
const coverPage = [
  spacer(800),
  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [9360],
    rows: [new TableRow({
      children: [new TableCell({
        borders: noBorders,
        shading: { fill: COLORS.heading_bg, type: ShadingType.CLEAR },
        margins: { top: 500, bottom: 500, left: 400, right: 400 },
        children: [
          new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'ApptMasters 2.0', size: 64, bold: true, font: 'Arial', color: 'FFFFFF' })] }),
          spacer(60),
          new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Integrated Life Management Platform', size: 28, font: 'Arial', color: 'AAAACC', italics: true })] }),
          spacer(120),
          new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Product Redesign & Build Plan', size: 24, font: 'Arial', color: 'CCCCDD' })] }),
          spacer(60),
          new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Organized Around the Five Pillars of Agentic AI Best Practices', size: 22, font: 'Arial', color: '8888AA', italics: true })] }),
        ]
      })]
    })]
  }),
  spacer(400),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: 'Version 2.0  |  Strategic Planning Document', size: 20, font: 'Arial', color: '777777' })]
  }),
  new Paragraph({ children: [new PageBreak()] }),
];

// ─────────────────────────────────────────────
// INTRO: What are the Five Pillars?
// ─────────────────────────────────────────────
const introSection = [
  makeHeading1('The Five Pillars of Agentic AI Best Practices'),
  makeBody('This document organizes the entire ApptMasters 2.0 redesign — every feature, every improvement, every edge case — through the lens of the five pillars of agentic AI best practices. These pillars define how a modern, intelligent platform should think, remember, act, collaborate, and remain trustworthy.'),
  spacer(120),
  makeThreeColTable(
    'Pillar', 'Definition', 'ApptMasters Application',
    [
      ['1. Perception & Context', 'Understanding the full situation before acting', 'Room states, chore status, balances, user context'],
      ['2. Memory & State', 'Retaining and using history intelligently', 'Expense history, chore logs, maintenance records'],
      ['3. Action & Execution', 'Taking the right action at the right time', 'Notifications, automations, recurring tasks'],
      ['4. Collaboration & Communication', 'Coordinating between multiple agents/users', 'Roommate coordination, voting, activity feed'],
      ['5. Safety, Ethics & Trust', 'Acting within boundaries users can trust', 'Dispute resolution, data privacy, audit trails'],
    ],
    COLORS.heading_bg
  ),
  spacer(200),
  new Paragraph({ children: [new PageBreak()] }),
];

// ─────────────────────────────────────────────
// PILLAR 1: PERCEPTION & CONTEXT
// ─────────────────────────────────────────────
const pillar1 = [
  makePillarBanner('1', 'Perception & Context', 'Understanding the full apartment situation before surfacing anything to the user', COLORS.pillar1),
  spacer(200),
  makeBody('A smart platform does not show raw data — it understands what is happening right now in the apartment and surfaces only what matters. ApptMasters must perceive the current state of every room, every balance, and every relationship before deciding what to show.'),
  spacer(160),

  makeHeading2('1.1  Apartment State Awareness', COLORS.pillar1),
  makeBody('The app must always know the current state of the apartment across all dimensions simultaneously:'),
  spacer(80),
  makeTwoColFeatureTable([
    ['Room Cleanliness', 'Each room carries a live status: Clean, Acceptable, Needs Attention, or Overdue. Set automatically from chore completion timestamps.'],
    ['Inventory Levels', 'Grocery and supplies tracker flags items as Stocked, Low, or Out. Derived from purchase logs and manual updates.'],
    ['Financial State', 'Each roommate\'s balance is always current. The system knows who owes what without anyone having to ask.'],
    ['Chore Workload', 'Point-weighted chore system tracks whether workload is balanced across roommates over the past 30 days.'],
    ['Maintenance Status', 'Outstanding issues are always surfaced — nothing falls through the cracks because it was \'reported but forgotten.\''],
  ], COLORS.pillar1, 'State Dimension', 'How ApptMasters Perceives It'),
  spacer(160),

  makeHeading2('1.2  Contextual Home Dashboard', COLORS.pillar1),
  makeBody('Replace the three-module landing page with a single unified dashboard that perceives and surfaces the apartment\'s current state at a glance. The dashboard is not a menu — it is a live snapshot.'),
  spacer(80),
  makeBullet('Today\'s chores — who is responsible, what is overdue, what was completed'),
  makeBullet('Your current balance — what you owe or are owed, updated in real time'),
  makeBullet('Grocery and supplies — items flagged as low or out by any roommate'),
  makeBullet('Upcoming events — maintenance visits, guests arriving, rent due date'),
  makeBullet('Recent activity — the last five apartment actions, with timestamps'),
  makeBullet('Apartment pulse — one optional emoji per roommate to set the weekly mood'),
  spacer(160),

  makeHeading2('1.3  Room-Level Context', COLORS.pillar1),
  makeBody('Every feature in the app is room-aware. Chores belong to rooms. Issues belong to rooms. Cleanliness scores belong to rooms. This means the app can answer: \'What is the current state of the kitchen?\' with full fidelity.'),
  spacer(80),
  makeBody('Configurable room types at apartment setup:'),
  makeBullet('Kitchen'),
  makeBullet('Living room'),
  makeBullet('Bathroom (numbered if multiple — Bathroom 1, Bathroom 2)'),
  makeBullet('Hallway and entrance'),
  makeBullet('Shared balcony or yard'),
  makeBullet('Laundry room'),
  makeBullet('Custom room — name it anything'),
  spacer(160),

  makeHeading2('1.4  User Context & Profiles', COLORS.pillar1),
  makeBody('The system perceives each user\'s context individually. What the app shows you is personalized to your role, your chores, your balance, and your room.'),
  spacer(80),
  makeBullet('Move-in date — determines when your rotation starts'),
  makeBullet('Room assignment — determines which private bathroom you clean'),
  makeBullet('Dietary flags — surfaces relevant alerts when fridge items are added'),
  makeBullet('Vacation mode — removes you from rotation and redistributes your chores automatically'),
  makeBullet('Admin vs. member role — determines what settings you can change'),
  spacer(160),

  makeHeading2('1.5  Edge Cases in Perception', COLORS.pillar1),
  makeBody('These scenarios test the system\'s ability to perceive complex situations correctly:'),
  spacer(80),
  makeBullet('Roommate moves out mid-lease — their historical data is preserved, active chores are redistributed, profile becomes \'former roommate\''),
  makeBullet('New roommate joins mid-rotation — chore schedule recalculates from their join date, not the apartment start date'),
  makeBullet('Sublet scenario — original tenant retains financial responsibility, subtenant has limited access'),
  makeBullet('Unequal rooms — roommate with master bedroom pays higher rent share; this is configured at setup and reflected in all calculations'),
  makeBullet('Chore marked done without being done — photo log provides visual verification context'),
  new Paragraph({ children: [new PageBreak()] }),
];

// ─────────────────────────────────────────────
// PILLAR 2: MEMORY & STATE
// ─────────────────────────────────────────────
const pillar2 = [
  makePillarBanner('2', 'Memory & State', 'Retaining the full history so the apartment never forgets anything important', COLORS.pillar2),
  spacer(200),
  makeBody('An agentic system without persistent memory is useless. ApptMasters must remember every expense, every chore completion, every maintenance issue, and every house rule — forever. This history is not just for reference; it actively informs current decisions and surfaces relevant context.'),
  spacer(160),

  makeHeading2('2.1  Financial Memory', COLORS.pillar2),
  makeBody('The finance module must retain complete, queryable history. Not just balances — the full ledger.'),
  spacer(80),
  makeTwoColFeatureTable([
    ['Transaction History', 'Every expense ever added, with date, payer, amount, split method, and who was included. Filterable by person, date range, and category.'],
    ['Settlement Log', 'Every \'settle up\' action is recorded — who paid whom, how much, on what date, and whether both parties confirmed.'],
    ['Recurring Expense Memory', 'The system remembers which expenses repeat monthly and auto-generates them. Rent, utilities, internet — never re-entered manually.'],
    ['Monthly Statements', 'Exportable PDF summary of every month\'s expenses, splits, and settlements. Useful for tax time and move-out disputes.'],
    ['Debt Simplification History', 'When the system suggests \'Alex pays Sam directly to simplify,\' it logs the suggestion and the outcome.'],
  ], COLORS.pillar2, 'Memory Type', 'What Is Retained and Why'),
  spacer(160),

  makeHeading2('2.2  Chore & Room Memory', COLORS.pillar2),
  makeBody('Chore history creates accountability without confrontation. The record speaks for itself.'),
  spacer(80),
  makeBullet('Complete chore completion log — who did what, when, with optional photo evidence'),
  makeBullet('Overdue history — how many times each chore was skipped and by whom'),
  makeBullet('Swap history — every chore swap requested and whether it was honored'),
  makeBullet('Workload balance over time — 30-day rolling view of point distribution per roommate'),
  makeBullet('Vacation coverage log — who covered whose chores and when, so it can be reciprocated'),
  spacer(160),

  makeHeading2('2.3  Maintenance Memory', COLORS.pillar2),
  makeBody('The maintenance log is one of the most legally important features in the app. It creates a timestamped record that protects all roommates.'),
  spacer(80),
  makeBullet('Every issue ever reported — room, description, photo, date, reporter'),
  makeBullet('Status history — each status change with timestamp and responsible party'),
  makeBullet('Landlord communication log — every contact, what was said, what was promised'),
  makeBullet('Move-out documentation — before and after photos per room, exportable as PDF'),
  makeBullet('Emergency incident log — unauthorized landlord entry, noise complaints, pest sightings'),
  spacer(160),

  makeHeading2('2.4  Inventory Memory', COLORS.pillar2),
  makeBody('The fridge and household supplies tracker needs memory to be useful — otherwise it is just a list.'),
  spacer(80),
  makeBullet('Purchase history — who bought what and when, enabling fair rotation detection'),
  makeBullet('Consumption patterns — how fast does the apartment go through dish soap? Auto-suggest reorder timing'),
  makeBullet('Hands-off food log — who has marked what as theirs, permanently visible'),
  makeBullet('Shared items registry with condition logs — photo on arrival, photo on departure'),
  spacer(160),

  makeHeading2('2.5  Rules & Agreement Memory', COLORS.pillar2),
  makeBody('House rules must be versioned. When a rule changes, the old version is not deleted — it is archived with the date it was in effect.'),
  spacer(80),
  makeBullet('Full rules history — every rule that was ever passed, amended, or rejected'),
  makeBullet('Voting records — who voted for what on every house rule decision'),
  makeBullet('Rule acknowledgment log — new roommates must acknowledge existing rules on join, and that acknowledgment is stored'),
  makeBullet('Violation flags — neutral, anonymous flagging with timestamps, no public shaming'),
  new Paragraph({ children: [new PageBreak()] }),
];

// ─────────────────────────────────────────────
// PILLAR 3: ACTION & EXECUTION
// ─────────────────────────────────────────────
const pillar3 = [
  makePillarBanner('3', 'Action & Execution', 'Taking the right action at the right time without requiring the user to ask', COLORS.pillar3),
  spacer(200),
  makeBody('The best features in ApptMasters are the ones that act before the user has to think about it. Reminders fire automatically. Recurring expenses generate themselves. Grocery lists update when items are purchased. The system acts; the user just lives.'),
  spacer(160),

  makeHeading2('3.1  Automated Notifications', COLORS.pillar3),
  makeBody('Notifications are the most important execution feature. A chore schedule nobody gets reminded about is just a calendar nobody checks.'),
  spacer(80),
  makeTwoColFeatureTable([
    ['Chore Reminder', '24 hours before a chore is due, the assigned roommate receives a push notification.'],
    ['Chore Overdue Alert', 'If a chore is not marked complete within 6 hours of its deadline, it escalates to an overdue alert.'],
    ['Roommate Nudge', 'Any roommate can send a soft nudge via the app — \'gentle reminder\' — without direct confrontation.'],
    ['Expense Alert', 'When a new expense is added that includes you, you are notified immediately with the amount and description.'],
    ['Settle Up Reminder', 'If your balance exceeds a user-set threshold (e.g. $20) for more than 7 days, a reminder fires.'],
    ['Low Stock Alert', 'When a household item hits the reorder threshold, the designated buyer is notified.'],
    ['Rent Due Reminder', '5 days before and 1 day before rent due date, all roommates are reminded.'],
    ['Maintenance Follow-Up', 'If an issue stays in \'In Progress\' for more than 7 days with no update, the responsible person is reminded.'],
    ['Weekly Summary', 'Every Sunday evening, each roommate receives a clean summary of the week\'s chores, balances, and upcoming tasks.'],
  ], COLORS.pillar3, 'Trigger', 'Action Taken'),
  spacer(160),

  makeHeading2('3.2  Recurring Automations', COLORS.pillar3),
  makeBody('Recurring expenses are the single most impactful feature missing from v1. They eliminate the most common monthly friction entirely.'),
  spacer(80),
  makeBullet('Rent — each roommate\'s share configured once, generates automatically on the set day each month'),
  makeBullet('Utilities — electricity, water, gas — added once, recurs forever until cancelled'),
  makeBullet('Internet — fixed monthly split, auto-generated'),
  makeBullet('Streaming subscriptions — Netflix, Spotify Family, etc. — split among the roommates who opted in'),
  makeBullet('Cleaning supplies budget — a shared monthly contribution to the apartment fund'),
  makeBullet('Each recurring expense is editable, pausable, or cancellable at any time'),
  spacer(160),

  makeHeading2('3.3  Chore Rotation Engine', COLORS.pillar3),
  makeBody('The rotation engine executes chore assignments automatically so no roommate has to think about scheduling.'),
  spacer(80),
  makeBullet('Three assignment modes: Rotating (auto-cycles), Fixed (always the same person), Voluntary (first taker)'),
  makeBullet('Vacation mode — when activated, the absent roommate\'s chores auto-distribute to available members'),
  makeBullet('Swap execution — one roommate requests, the other confirms, the schedule updates instantly'),
  makeBullet('New roommate integration — rotation recalculates from join date, balancing points going forward'),
  makeBullet('Move-out handling — departed roommate\'s chores redistribute immediately upon their departure date'),
  spacer(160),

  makeHeading2('3.4  Grocery & Inventory Automations', COLORS.pillar3),
  makeBullet('When a grocery list item is marked \'purchased,\' it automatically moves to \'in stock\' inventory'),
  makeBullet('When inventory quantity drops to the reorder threshold, the item auto-adds back to the grocery list'),
  makeBullet('Purchase rotation — system tracks who bought last and suggests whose turn it is next'),
  makeBullet('Expiry alerts — flag items nearing expiration to reduce food waste'),
  spacer(160),

  makeHeading2('3.5  Finance Automations', COLORS.pillar3),
  makeBullet('Debt simplification — when A owes B and B owes C, suggest A pays C directly to reduce transaction count'),
  makeBullet('Venmo / PayPal / CashApp deeplinks — pre-fill amount and note, one tap to settle'),
  makeBullet('Month-end statement generation — auto-produced on the last day of the month, no manual trigger needed'),
  makeBullet('Expense dispute freeze — when flagged, the split is frozen and no settlement can occur until resolved'),
  new Paragraph({ children: [new PageBreak()] }),
];

// ─────────────────────────────────────────────
// PILLAR 4: COLLABORATION & COMMUNICATION
// ─────────────────────────────────────────────
const pillar4 = [
  makePillarBanner('4', 'Collaboration & Communication', 'Coordinating multiple people with different needs without creating conflict', COLORS.pillar4),
  spacer(200),
  makeBody('ApptMasters exists because multiple humans with different habits, schedules, and expectations have to share a space. Every collaboration feature must reduce friction, prevent misunderstanding, and make coordination feel effortless rather than adversarial.'),
  spacer(160),

  makeHeading2('4.1  Apartment Identity & Onboarding', COLORS.pillar4),
  makeBody('This is the missing foundation of v1. All collaboration depends on a shared apartment identity.'),
  spacer(80),
  makeBullet('One roommate creates the apartment with a name (e.g., \'Casa Diallo\', \'4B Gang\')'),
  makeBullet('Generates a shareable 6-digit invite code and a one-tap invite link'),
  makeBullet('Joining roommates set their move-in date, room assignment, and profile'),
  makeBullet('Admin role for the creator — can remove members and manage apartment settings'),
  makeBullet('Guest mode — short-term visitors with read-only access to relevant sections'),
  makeBullet('New roommates must acknowledge house rules before their profile is fully activated'),
  spacer(160),

  makeHeading2('4.2  Activity Feed — The Collaboration Spine', COLORS.pillar4),
  makeBody('Replace standalone chat with a contextual activity stream. Every apartment action generates a feed item automatically. This is the social layer.'),
  spacer(80),
  makeTwoColFeatureTable([
    ['Expense Added', '\'Alex added a $45 expense for electricity — split 3 ways\''],
    ['Balance Settled', '\'Jordan paid Sam $32 — balance cleared\''],
    ['Chore Completed', '\'Mamadou completed: Kitchen deep clean\''],
    ['Chore Overdue', '\'Bathroom cleaning is 2 days overdue — assigned to Alex\''],
    ['Issue Reported', '\'New maintenance issue: Shower drain clogged in Bathroom 1\''],
    ['Issue Resolved', '\'Landlord fixed the heating unit — issue closed\''],
    ['Rule Passed', '\'New house rule: No guests after midnight on weekdays — 3/3 votes\''],
    ['Item Low', '\'Dish soap is running low — someone flagged it\''],
    ['Roommate Announcement', '\'Sam: I\'ll be away Dec 14-21, vacation mode activated\''],
    ['Roommate Joined', '\'Welcome Fatou — joined Casa Diallo on Dec 1\''],
  ], COLORS.pillar4, 'Event Type', 'Feed Message Example'),
  spacer(160),

  makeHeading2('4.3  Announcements (Lightweight Communication)', COLORS.pillar4),
  makeBody('Not a chat app. Not a forum. Just a simple way to post something the whole apartment needs to know.'),
  spacer(80),
  makeBullet('Any roommate posts an announcement — it appears in the feed and triggers a notification'),
  makeBullet('Reactions only: thumbs up, noted, question mark — no threaded replies'),
  makeBullet('If it needs a real conversation, it goes to WhatsApp. This is for logistics.'),
  makeBullet('Examples: \'Plumber coming Thursday 10-2\', \'Having 4 friends over Saturday night\', \'Found a spider in the laundry room\''),
  spacer(160),

  makeHeading2('4.4  House Rules — Democratic Collaboration', COLORS.pillar4),
  makeBody('Rules reduce conflict by making expectations explicit and collectively agreed upon.'),
  spacer(80),
  makeBullet('Any roommate proposes a rule — it enters a 48-hour voting window'),
  makeBullet('Simple majority passes it — the rule enters the official House Rules document'),
  makeBullet('All roommates are notified when a new rule is proposed or passes'),
  makeBullet('Rules can be amended or repealed with another vote'),
  makeBullet('Rule discussion thread — limited, topic-specific comments before the vote closes'),
  makeBullet('Violation flagging — neutral, private, no public shaming — creates a log for reference'),
  spacer(160),

  makeHeading2('4.5  Shared Calendar', COLORS.pillar4),
  makeBullet('Guest visits — mark days when you are having people over so roommates are not surprised'),
  makeBullet('Maintenance visits — everyone sees the plumber is coming Thursday'),
  makeBullet('Rent due dates — shared, visible to all'),
  makeBullet('Roommate travel — vacation mode ties directly to calendar dates'),
  makeBullet('Apartment events — house meeting, shared dinner, lease renewal deadline'),
  spacer(160),

  makeHeading2('4.6  Built-In Communication Layer', COLORS.pillar4),
  makeBody('ApptMasters includes a private, apartment-scoped communication suite. Not a social network — a dedicated intercom for the people who share your space. Every roommate is automatically added to the apartment communication space on join. Four modes are supported:'),
  spacer(80),

  makeHeading3('Text Messaging', COLORS.pillar4),
  makeBullet('Apartment group chat — always-on thread for all roommates'),
  makeBullet('1-on-1 direct messages between any two roommates'),
  makeBullet('Contextual quick-reply — reply directly to an activity feed event inline'),
  makeBullet('Message history retained for 90 days by default, configurable per apartment'),
  makeBullet('Read receipts — optional, can be disabled per user in settings'),
  makeBullet('Typing indicators in group and DM threads'),
  spacer(120),

  makeHeading3('Voice Calls', COLORS.pillar4),
  makeBullet('One-tap audio call to a specific roommate or the full apartment group'),
  makeBullet('Primary use case: calling from the grocery store to confirm what is needed'),
  makeBullet('Call log — missed calls are visible in the chat thread, not just as a notification'),
  makeBullet('Do Not Disturb integration — calls auto-silence during apartment quiet hours unless marked urgent'),
  makeBullet('No call recording — explicitly disabled by default; enabling requires all-party consent'),
  spacer(120),

  makeHeading3('Video Calls', COLORS.pillar4),
  makeBullet('1-on-1 or full apartment group video call'),
  makeBullet('Primary use cases: remote roommate meetings, showing a maintenance issue live, coordinating move-in or move-out logistics'),
  makeBullet('Screen share — optional, useful for reviewing shared documents like the lease or expense history together'),
  makeBullet('Video calls do not record and are not logged beyond the call event in the chat thread'),
  spacer(120),

  makeHeading3('Image Sharing', COLORS.pillar4),
  makeBullet('Send photos and short videos directly in any chat thread'),
  makeBullet('Deep integration with app modules — a maintenance photo taken in the Issues tracker can be shared directly to the group chat in one tap, no re-uploading'),
  makeBullet('Fridge and grocery receipt photos shareable inline'),
  makeBullet('Move-out and damage documentation photos shareable for group review before submission'),
  makeBullet('Media storage cap per apartment — 2GB default, with a clear indicator and archiving option when approaching the limit'),
  makeBullet('Images in chat are scoped exclusively to the apartment group or the DM recipient — never public'),
  spacer(160),

  makeHeading2('4.7  Communication Edge Cases', COLORS.pillar4),
  makeTwoColFeatureTable([
    ['Relationship breakdown', 'A roommate can mute or restrict a specific person — silencing their messages and calls — without leaving the apartment or triggering a visible notification to that person.'],
    ['Emergency broadcast', 'Any roommate can send an urgent message that overrides Do Not Disturb on all devices. Reserved for genuine emergencies only — flagged if used repeatedly without cause.'],
    ['Guest access', 'Guests have read-only access to the activity feed. They cannot send messages, initiate calls, or share media.'],
    ['Roommate moves out', 'On departure, their chat history remains visible to remaining members for continuity, but they lose access to all future messages and calls immediately.'],
    ['Media as legal evidence', 'Photos shared in chat are timestamped and tied to the sender. If a maintenance image becomes relevant to a deposit dispute, it can be exported from the chat thread as part of the documentation package.'],
    ['Notification fatigue', 'Communication notifications are separate from apartment-action notifications. Users can silence chat without silencing chore or finance alerts.'],
  ], COLORS.pillar4, 'Scenario', 'How the System Handles It'),
  spacer(160),

  makeHeading2('4.8  What We Are NOT Building', COLORS.pillar4),
  makeBody('Explicit scope reduction to keep communication features focused and high-quality:'),
  spacer(80),
  makeBullet('No building-wide community social network — that is a v3 problem'),
  makeBullet('No public profiles or followers — this is a private tool for a closed group'),
  makeBullet('No stories, status updates, or broadcast social content'),
  makeBullet('No external contacts outside the apartment group'),
  makeBullet('No gamification or leaderboards — these create resentment, not motivation'),
  new Paragraph({ children: [new PageBreak()] }),
];

// ─────────────────────────────────────────────
// PILLAR 5: SAFETY, ETHICS & TRUST
// ─────────────────────────────────────────────
const pillar5 = [
  makePillarBanner('5', 'Safety, Ethics & Trust', 'Acting within boundaries all roommates can rely on — even when relationships are strained', COLORS.pillar5),
  spacer(200),
  makeBody('An agentic system operating in a shared living environment touches money, privacy, physical safety, and interpersonal relationships. Trust is the product. Every feature must be designed with the assumption that roommate relationships sometimes break down — and the app must protect everyone equally when they do.'),
  spacer(160),

  makeHeading2('5.1  Financial Safety', COLORS.pillar5),
  makeBody('Money is the most common source of roommate conflict and the most legally sensitive area of the app.'),
  spacer(80),
  makeBullet('Expense dispute system — any roommate can flag an expense as disputed, which freezes the split until all parties resolve it'),
  makeBullet('Both parties must confirm a settlement — one-sided confirmation is not valid'),
  makeBullet('No payment processing — the app never touches money directly, only records and facilitates'),
  makeBullet('Move-out balance lock — a departing roommate cannot mark themselves as fully settled until all counterparties agree'),
  makeBullet('Forgive/write-off flow — admin can forgive a debt with all parties\' consent, and it is logged permanently'),
  makeBullet('Full audit trail — every financial action has a timestamp, actor, and cannot be deleted'),
  spacer(160),

  makeHeading2('5.2  Communication Privacy & Safety', COLORS.pillar5),
  makeBody('The built-in communication layer touches private conversations, voice, and video. It requires the strongest privacy guarantees in the platform.'),
  spacer(80),
  makeBullet('End-to-end encryption for all direct messages and 1-on-1 calls'),
  makeBullet('Group chat messages are encrypted in transit and at rest — accessible only to current apartment members'),
  makeBullet('Call recording is off by default and cannot be enabled unilaterally — all parties must consent'),
  makeBullet('Video call frames are never stored — only call event metadata is logged'),
  makeBullet('Mute and restrict controls are silent — the restricted person receives no notification'),
  makeBullet('Media shared in chat is purged from servers when the message history retention window expires'),
  makeBullet('Departed roommates lose communication access immediately — no delayed cutoff'),
  makeBullet('Emergency broadcast abuse — repeated misuse is flagged to the admin and logged'),
  spacer(160),

  makeHeading2('5.3  Privacy & Data Ethics', COLORS.pillar5),
  makeBullet('Hands-off food tags are respected — the system logs access attempts to private fridge items'),
  makeBullet('Violation flags are private — only the flagging person and admins see them, never the whole group'),
  makeBullet('Apartment data is isolated — no data from one apartment is ever visible to another'),
  makeBullet('Departure privacy — when a roommate leaves, their personal profile data is returned to them and removed from active views'),
  makeBullet('No tracking of physical location — the app does not use GPS or location data'),
  makeBullet('Export your own data — any user can export all their personal data at any time'),
  spacer(160),

  makeHeading2('5.4  Conflict De-escalation Design', COLORS.pillar5),
  makeBody('Features are designed to prevent confrontation, not enable it. This is an ethical design principle, not just a UX concern.'),
  spacer(80),
  makeBullet('No rating system — replaced with kudos-only acknowledgment. Negative ratings create resentment.'),
  makeBullet('Chore photo log — visual proof eliminates \'did you actually clean it?\' arguments before they start'),
  makeBullet('Soft nudge — the system sends the reminder, not you. \'The app reminded me\' lands differently than \'I\'m telling you again\''),
  makeBullet('Neutral activity feed language — the feed states facts, not judgments. \'Overdue\' not \'neglected\''),
  makeBullet('Anonymous violation flags — keeps accountability without interpersonal friction'),
  makeBullet('Dispute resolution flow — structured, steps-based, with a neutral log visible to all parties'),
  spacer(160),

  makeHeading2('5.5  Maintenance & Legal Safety', COLORS.pillar5),
  makeBody('The maintenance log doubles as legal documentation. This is one of the most underrated features in the entire platform.'),
  spacer(80),
  makeBullet('Timestamped photo documentation of all issues — this is your evidence if the landlord withholds the deposit'),
  makeBullet('Landlord unauthorized entry log — date, time, who noticed it, stored permanently'),
  makeBullet('Move-out checklist with before/after photos — exportable as PDF, signable by all roommates'),
  makeBullet('Lease document storage — upload lease, addendums, and notices so all roommates have access'),
  makeBullet('Emergency contact designation — who calls the landlord at 2am? Defined at setup, not discovered in a crisis'),
  spacer(160),

  makeHeading2('5.6  Governance & Admin Controls', COLORS.pillar5),
  makeBullet('Admin cannot unilaterally delete another user\'s expense records — changes require dual confirmation'),
  makeBullet('Admin can remove a roommate but cannot erase their historical contributions'),
  makeBullet('All rule changes require a vote — admin has no override power on house rules'),
  makeBullet('Apartment can be transferred to a new admin if the original admin moves out'),
  makeBullet('Account deletion is \'soft\' — data is retained for 90 days for dispute resolution, then permanently purged'),
  spacer(160),

  makeHeading2('5.7  Edge Cases That Test the Trust Model', COLORS.pillar5),
  makeBody('These scenarios are where trust breaks down in practice. The system must handle all of them.'),
  spacer(80),
  makeBullet('Roommate moves out with unpaid balance — balance lock prevents clean departure until resolved or forgiven'),
  makeBullet('Disputed chore photo — the photo is timestamped and geo-tagged to the apartment; cannot be submitted from elsewhere'),
  makeBullet('Admin abuses power — any member can escalate a complaint to a full group vote to remove or replace the admin'),
  makeBullet('Expense added maliciously — dispute system freezes it immediately; audit log preserves the original submission'),
  makeBullet('New roommate does not agree with existing rules — negotiation window before profile activates'),
  makeBullet('Food allergy not respected — dietary flags are shown prominently when adding shared food items'),
  makeBullet('Landlord dispute over deposit — the maintenance log + move-out PDF becomes your legal documentation package'),
  new Paragraph({ children: [new PageBreak()] }),
];

// ─────────────────────────────────────────────
// SECTION 6: BUILD PLAN
// ─────────────────────────────────────────────
const buildPlan = [
  makeHeading1('Revised Build Plan — Phased by Pillar Priority'),
  makeBody('Each phase maps to one or more pillars. The sequence is intentional: foundation first, then memory, then action, then collaboration, then trust enforcement.'),
  spacer(160),
  makeThreeColTable(
    'Phase', 'Pillar Focus', 'Deliverables',
    [
      ['Phase 1 (Weeks 1–3)', 'Pillar 4 — Collaboration Foundation', 'Apartment creation, invite system, member profiles, admin roles, room configuration, onboarding flow'],
      ['Phase 2 (Weeks 4–6)', 'Pillar 1 — Perception', 'Unified home dashboard, chore scheduler with rotation engine, room-level state tracking, photo log'],
      ['Phase 3 (Weeks 7–10)', 'Pillar 2 — Memory', 'Full finance ledger, recurring expenses, transaction history, monthly statements, maintenance log, issue tracker'],
      ['Phase 4 (Weeks 11–13)', 'Pillar 3 — Action', 'All notification types, chore automation engine, inventory automations, debt simplification, payment deeplinks'],
      ['Phase 5 (Weeks 14–15)', 'Pillar 4 — Collaboration', 'Activity feed, announcements, house rules voting, shared calendar, grocery list with purchase flow'],
      ['Phase 6 (Weeks 16–17)', 'Pillars 4 & 5 — Communication', 'Group chat, direct messaging, voice calls, video calls, image sharing, encryption, mute/restrict controls, media storage management'],
      ['Phase 7 (Weeks 18–19)', 'Pillar 2 — Memory (Inventory)', 'Shared items registry, household supplies tracker, hands-off tagging, expiry alerts, purchase rotation'],
      ['Phase 8 (Weeks 20–21)', 'Pillar 5 — Safety & Trust', 'Dispute resolution flow, balance lock on move-out, audit trails, move-out PDF export, comms privacy controls'],
      ['Phase 9 (Week 22)', 'All Pillars — Integration', 'Cross-module polish, mobile optimization, performance tuning, data export, final QA'],
    ],
    COLORS.heading_bg
  ),
  spacer(200),

  makeHeading2('What We Are Cutting from v1'),
  makeTwoColFeatureTable([
    ['Rating system', 'Replaced by kudos-only acknowledgment. Negative ratings create resentment without productive outcomes.'],
    ['Standalone social-only chat', 'Replaced by the built-in communication suite (text, voice, video, image) integrated with the activity feed — not a disconnected chat module.'],
    ['Building-wide community', 'Out of scope for v1 and v2. Focus on one apartment at a time.'],
    ['Generic About Us tab', 'Irrelevant inside a utility app. Replaced by apartment profile settings.'],
  ], COLORS.pillar5, 'Feature Cut', 'Reason'),
  spacer(200),

  makeHeading2('The North Star Test'),
  spacer(80),
  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [9360],
    rows: [new TableRow({
      children: [new TableCell({
        borders: noBorders,
        shading: { fill: COLORS.light_gray, type: ShadingType.CLEAR },
        margins: { top: 200, bottom: 200, left: 300, right: 300 },
        children: [
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [new TextRun({ text: 'Every feature must pass this test:', size: 22, font: 'Arial', color: COLORS.dark_text, italics: true })]
          }),
          spacer(80),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [new TextRun({ text: '"Would this prevent an argument or make a hard conversation unnecessary?"', size: 26, font: 'Arial', color: COLORS.heading_bg, bold: true })]
          }),
          spacer(80),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [new TextRun({ text: 'If yes — build it. If no — cut it.', size: 22, font: 'Arial', color: COLORS.dark_text, italics: true })]
          }),
        ]
      })]
    })]
  }),
];

// ─────────────────────────────────────────────
// ASSEMBLE DOCUMENT
// ─────────────────────────────────────────────
const doc = new Document({
  numbering: {
    config: [
      {
        reference: 'bullets',
        levels: [
          { level: 0, format: LevelFormat.BULLET, text: '\u2022', alignment: AlignmentType.LEFT,
            style: { paragraph: { indent: { left: 720, hanging: 360 } }, run: { font: 'Arial', size: 22 } } },
          { level: 1, format: LevelFormat.BULLET, text: '\u25E6', alignment: AlignmentType.LEFT,
            style: { paragraph: { indent: { left: 1080, hanging: 360 } }, run: { font: 'Arial', size: 20 } } },
        ]
      }
    ]
  },
  styles: {
    default: { document: { run: { font: 'Arial', size: 22, color: COLORS.dark_text } } },
    paragraphStyles: [
      { id: 'Heading1', name: 'Heading 1', basedOn: 'Normal', next: 'Normal', quickFormat: true,
        run: { size: 36, bold: true, font: 'Arial', color: COLORS.dark_text },
        paragraph: { spacing: { before: 400, after: 200 }, outlineLevel: 0 } },
      { id: 'Heading2', name: 'Heading 2', basedOn: 'Normal', next: 'Normal', quickFormat: true,
        run: { size: 28, bold: true, font: 'Arial', color: COLORS.dark_text },
        paragraph: { spacing: { before: 300, after: 160 }, outlineLevel: 1 } },
      { id: 'Heading3', name: 'Heading 3', basedOn: 'Normal', next: 'Normal', quickFormat: true,
        run: { size: 24, bold: true, font: 'Arial', color: COLORS.dark_text },
        paragraph: { spacing: { before: 240, after: 120 }, outlineLevel: 2 } },
    ]
  },
  sections: [{
    properties: {
      page: {
        size: { width: 12240, height: 15840 },
        margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 }
      }
    },
    headers: {
      default: new Header({
        children: [
          new Paragraph({
            border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: 'CCCCCC', space: 1 } },
            children: [
              new TextRun({ text: 'ApptMasters 2.0 — Five Pillars Plan', size: 18, font: 'Arial', color: '888888' }),
            ]
          })
        ]
      })
    },
    footers: {
      default: new Footer({
        children: [
          new Paragraph({
            border: { top: { style: BorderStyle.SINGLE, size: 4, color: 'CCCCCC', space: 1 } },
            tabStops: [{ type: TabStopType.RIGHT, position: TabStopPosition.MAX }],
            children: [
              new TextRun({ text: 'Confidential — Internal Planning Document', size: 16, font: 'Arial', color: '888888' }),
              new TextRun({ text: '\tPage ', size: 16, font: 'Arial', color: '888888' }),
            ]
          })
        ]
      })
    },
    children: [
      ...coverPage,
      ...introSection,
      ...pillar1,
      ...pillar2,
      ...pillar3,
      ...pillar4,
      ...pillar5,
      ...buildPlan,
    ]
  }]
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync('/mnt/user-data/outputs/ApptMasters_FivePillars_Plan.docx', buffer);
  console.log('Done.');
});
