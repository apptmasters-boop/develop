# ApptMasters 2.0 — Full Session Notes
**Status:** Living document — all decisions, features, and changes captured  
**Last updated:** End of brainstorm & planning session

---

## What This File Is

This document captures everything discussed and decided across the full planning session for ApptMasters 2.0. Use it as ground truth before any future build session.

---

## Original Spec (v1) — What We Started With

Three-module app:
- **Apt Management** — fridge tracker, cleaning/bathroom schedules, rating system
- **MyFinance** — settle up, add expense, unsettled balance dashboard
- **Social** — friends list, groups, feed, chat

Tech stack: React/Next.js + Tailwind, Node.js/Express or FastAPI, MySQL/PostgreSQL, JWT/Auth0

---

## Key Decisions Made

### What we cut
| Feature | Reason |
|---|---|
| Rating system | Passive-aggressive, creates resentment. Replaced with kudos-only. |
| Standalone social chat | Nobody needs another chat app. Replaced with integrated comms suite + activity feed. |
| Building-wide community | Too ambitious for v1. Deferred to v3. |
| Generic "About Us" tab | Irrelevant in a utility app. Replaced by apartment settings. |

### What we kept and improved
| Feature | Improvement |
|---|---|
| Fridge tracker | Reframed as shared grocery list that auto-converts to inventory on purchase |
| Chore scheduler | Added push notifications/reminders — without these it's just a calendar nobody checks |
| Finance module | Added recurring expenses, transaction history, debt simplification, Venmo/PayPal deeplinks |

### What we added (new)
| Feature | Why |
|---|---|
| Apartment invite system | The missing foundation — everything depends on shared apartment identity |
| Unified home dashboard | One screen: balance + chores + feed + inventory alerts |
| Room-level organization | Chores, issues, and cleanliness all scoped to specific rooms |
| Maintenance & issues tracker | Legal documentation for deposit disputes, landlord comms log |
| House rules with voting | Democratic, transparent, versioned — reduces unspoken expectation conflicts |
| Shared items registry | Whose TV is that? Condition photos on arrival and departure |
| Built-in communication suite | Text, voice calls, video calls, image sharing — private to apartment only |
| Move-out checklist + PDF export | Before/after photos per room, exportable, signable |
| Shared calendar | Guests, maintenance visits, rent dates, roommate travel |

---

## Full Feature List by Module

### Foundation — Apartment Identity
- Create apartment with custom name
- 6-digit invite code + shareable link
- Member profiles: move-in date, room assignment, photo/color, dietary flags
- Admin role (creator): can remove members, manage settings, transfer admin
- Guest mode: read-only, no messaging or calls
- New roommates must acknowledge house rules before activation
- Vacation mode: removes from chore rotation, redistributes tasks
- Move-out flow: historical data preserved, active chores redistributed, profile → "former roommate"

### Module 1 — Home Dashboard
- Live balance (what you owe / are owed)
- Today's chores with status
- Grocery/supplies alerts (low or out)
- Upcoming events (maintenance, guests, rent)
- Last 5 activity feed items
- Optional apartment pulse (one emoji per roommate weekly)

### Module 2 — Rooms & Chores
- Configurable room types: Kitchen, Living room, Bathroom(s), Hallway, Laundry, Balcony, Custom
- Per-room: chore list, cleaning schedule, cleanliness status, photo log, maintenance flag
- Chore assignment modes: Rotating, Fixed, Voluntary
- Chore swapping: request + confirm flow
- Chore point system: weighted tasks, 30-day balance view per roommate
- Vacation mode: auto-redistribute chores
- Photo log: timestamped, eliminates "did you actually clean it" disputes
- Soft nudge: app sends reminder on your behalf
- Notifications: 24h reminder, overdue alert, weekly Sunday summary

### Module 3 — Finance
- One-time expenses: payer, amount, split method, participants
- Recurring expenses: rent, utilities, internet, subscriptions — auto-generated monthly
- Split methods: equal, custom %, per-person, one-time exception
- Running balance per person, always current
- Transaction history: filterable by person, date, category
- Settlement log: both parties must confirm
- Debt simplification: A owes B + B owes C → suggest A pays C directly
- Venmo/PayPal/CashApp deeplinks: pre-fill amount and note
- Monthly statement: auto-generated PDF on last day of month
- Apartment fund: shared pool for household supplies, running balance visible
- Dispute system: flag freezes split until all parties resolve
- Move-out balance lock: can't depart until settled or forgiven/written off
- Audit trail: every action timestamped, cannot be deleted

### Module 4 — Inventory
- Shared grocery list: add items, mark who's buying, mark purchased → auto moves to in-stock
- Household supplies tracker: toilet paper, soap, light bulbs, cleaning products
- Reorder threshold: auto-adds back to grocery list when low
- Purchase rotation: tracks who bought last, suggests whose turn it is
- Hands-off tagging: mark food as yours only
- Dietary flags: visible when adding shared food items
- Expiry tracking: flag items nearing expiration
- Shared items registry: furniture, appliances, tools — condition photos on arrival and departure
- Borrowing system: log when you're using someone's item

### Module 5 — Maintenance & Issues
- Issue reporting: room, description, photo, urgency level
- Status tracking: Reported → Contacted landlord → In progress → Resolved
- Photo documentation: timestamped, tied to reporter
- Landlord communication log: date, who contacted, what was said, outcome
- Unauthorized entry log: date, time, who noticed it
- Move-out checklist: per room, before/after photos, exportable PDF, signable by all
- Emergency contact designation: set at apartment setup

### Module 6 — Rules & Agreements
- House rules: propose → 48h vote → majority passes → added to document
- Rules are versioned: old versions archived, not deleted
- New roommates must acknowledge existing rules
- Rule discussion thread: limited comments before vote closes
- Violation flagging: private, anonymous, logged for reference
- Shared agreements: lease dates, rent due day, utility account holders, wifi password, emergency contacts
- Lease document storage: upload lease, addendums, notices

### Module 7 — Communication Suite
**Text messaging**
- Apartment group chat (always-on)
- 1-on-1 DMs between any two roommates
- Contextual quick-reply from activity feed events
- Message history: 90 days default, configurable
- Read receipts (optional, can disable)
- Typing indicators

**Voice calls**
- One-tap to a roommate or full group
- Call log visible in chat thread
- Auto-silences during apartment quiet hours (unless urgent)
- No recording (off by default, requires all-party consent to enable)

**Video calls**
- 1-on-1 or full group
- Screen share (optional)
- No recording, no storage beyond call event log

**Image sharing**
- Photos and short videos in any chat thread
- Deep integration: maintenance photo → share to group chat in one tap
- 2GB storage cap per apartment with archiving option
- Images are private to the chat recipient(s) only

**Communication safety**
- End-to-end encryption for DMs and 1-on-1 calls
- Group chat encrypted in transit and at rest
- Silent mute/restrict: affected person receives no notification
- Emergency broadcast: overrides DND, flagged if misused
- Departed roommates lose access immediately
- Chat notifications are separate from apartment-action notifications

### Module 8 — Social Feed (Activity Stream)
Automatic events (no manual input):
- Expense added or settled
- Chore completed or overdue
- Maintenance issue reported or resolved
- House rule proposed or passed
- Grocery item purchased or flagged low
- Roommate joined or moved out

Manual announcements:
- Any roommate can post to the group
- Reactions only: thumbs up, noted, question mark
- No threaded replies

### Module 9 — Shared Calendar
- Guest visit dates
- Maintenance visits
- Rent due dates
- Roommate travel/vacation
- Apartment events: house meetings, lease renewal deadline

---

## Five Pillars Mapping

| Pillar | What It Governs in ApptMasters |
|---|---|
| 1 — Perception & Context | Home dashboard, room states, live balances, user context |
| 2 — Memory & State | Finance history, chore logs, maintenance records, rules versioning |
| 3 — Action & Execution | Notifications, recurring automations, rotation engine, inventory triggers |
| 4 — Collaboration | Apartment identity, activity feed, comms suite, house rules voting, calendar |
| 5 — Safety & Trust | Dispute resolution, audit trails, comms encryption, conflict de-escalation design |

---

## Build Plan (22 Weeks)

| Phase | Weeks | Deliverables |
|---|---|---|
| 1 | 1–3 | Apartment creation, invite system, profiles, admin roles, room config, onboarding |
| 2 | 4–6 | Home dashboard, chore scheduler, room states, photo log, rotation engine |
| 3 | 7–10 | Finance ledger, recurring expenses, transaction history, monthly statements, maintenance log |
| 4 | 11–13 | All 9 notification types, chore automations, inventory automations, debt simplification, payment deeplinks |
| 5 | 14–15 | Activity feed, announcements, house rules voting, shared calendar, grocery list |
| 6 | 16–17 | Text, voice, video, image sharing — full comms suite with encryption and privacy controls |
| 7 | 18–19 | Shared items registry, supplies tracker, hands-off tagging, expiry alerts, purchase rotation |
| 8 | 20–21 | Dispute resolution, balance lock, audit trails, move-out PDF, privacy controls |
| 9 | 22 | Integration polish, mobile optimization, performance, data export, final QA |

---

## Edge Cases Catalogued

### Apartment identity
- Roommate moves out mid-lease: data preserved, chores redistributed, profile archived
- Sublet: original tenant stays financially responsible
- New roommate mid-rotation: schedule recalculates from join date
- Admin moves out: admin role transfers

### Finance
- Expense dispute: freezes split, both parties must resolve
- Move-out with unpaid balance: balance lock prevents clean departure
- Forgive/write-off: admin flow, logged permanently, requires consent
- Recurring expense paused: editing, pausing, cancelling any time
- Tax documentation: monthly PDF exports cover this

### Chores
- Chore marked done without being done: photo log provides visual verification
- Unequal apartments (private bathroom): chore point system balances workload
- Vacation: chores auto-redistribute, covered roommate gets credit for reciprocation

### Inventory
- Someone eats others' food: hands-off tag + activity log creates paper trail
- Move-out inventory: generate full shared items report for walkthrough
- Food allergy not respected: dietary flags shown prominently when adding items

### Maintenance
- Emergency at 2am: primary contact designated at setup
- Landlord enters without notice: unauthorized entry log with date/time
- Deposit dispute: full photo/maintenance log + move-out PDF is your evidence package

### Rules
- Rule conflict between roommates: discussion thread → vote
- New roommate disagrees with rules: negotiation window before activation
- Rule violation: anonymous flag, logged neutrally

### Communication
- Relationship breakdown: silent mute/restrict, no notification to affected person
- Emergency broadcast misuse: flagged to admin, logged
- Guest access: read-only feed, no messaging or calls
- Media as legal evidence: timestamped, exportable from chat thread

---

## North Star Test

> **"Would this prevent an argument or make a hard conversation unnecessary?"**  
> If yes — build it. If no — cut it.

---

## Output Files

| File | Description |
|---|---|
| `ApptMasters_FivePillars_Plan.docx` | Full formatted Word document — five pillars plan with all sections |
| `apptmasters_five_pillars_builder.js` | Node.js script that generates the Word document — edit and re-run to update |
| `apptmasters_session_notes.md` | This file — master reference for all decisions and features |

---

## Recommended Next Steps

1. **Wireframe priority screens** — Home dashboard, Finance ledger, Chat view, Room detail
2. **Define data model** — Users, Apartments, Rooms, Chores, Expenses, Messages, Issues, Rules
3. **Choose tech stack** — Confirm Next.js + Tailwind frontend, decide on WebSocket library for real-time comms (Socket.io recommended), choose WebRTC solution for voice/video (Daily.co or Agora)
4. **Start Phase 1 build** — Apartment identity is the unblocking foundation
